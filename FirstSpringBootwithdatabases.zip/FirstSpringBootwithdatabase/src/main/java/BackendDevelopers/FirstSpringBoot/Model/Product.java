package BackendDevelopers.FirstSpringBoot.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
//Linking the POJO Class to the table in the database.
@Entity
@Table(name="Product")



public class Product {
	@Id //In the database this column  is primary key 
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	//link product Name variable with ProductName column in the database
	@Column(name="productName")// In database we get the column name as productName.
	private String productName;
	
	public Product() {
		super();
		System.out.println("New Product Created");
	}
	
	public Product(int productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
		System.out.println("New Product Created with ProductID and ProductName...");
	}

	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
		System.out.println("Stored ProductId");
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
		System.out.println("Stored ProductName");
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + "]"+ " - "+ hashCode();
	}
	

}
