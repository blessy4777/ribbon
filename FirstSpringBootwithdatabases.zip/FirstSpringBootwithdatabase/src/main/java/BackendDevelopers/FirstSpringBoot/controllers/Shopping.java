package BackendDevelopers.FirstSpringBoot.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import BackendDevelopers.FirstSpringBoot.Model.Product;
import BackendDevelopers.FirstSpringBoot.service.ProductService;

@RestController // Normal java cls into a Controller
@RequestMapping("/shopping")
public class Shopping {
	public long visitorCount=0;
	@Autowired// for automatically injection purpose we use it .
	/* Creates an object for ProductService class automatically .
	 * So,that becomes a bean.That bean is injected into controller called(Shopping).
	 * This is ex of dependency injection.
	 */
	ProductService service;
	
	public Shopping()
	{
		System.err.println("Shopping Controller Created......");
	}
	//IF the URL is https://localhost:9080/shopping/,then class home() method and return the response to the client .
	@RequestMapping(path="/",method=RequestMethod.GET)

	public String home() {
		visitorCount++;
		String response="<html><body><h1>";
		response +="WELCOME TO ONLINE SHOPPING</h1><br>";
		response+="<b>You Are Visitor #</b>"+visitorCount;
		response+="</body></html>";
		return response;
	}
	/*produces is for in which format the server  is sending the  data  */
//   @RequestMapping(path="/list",method=RequestMethod.GET)
	@GetMapping(path="/list",produces=MediaType.APPLICATION_JSON_VALUE)// if the Url ends with /list and the request is GET then getProductsList()method returns the list of the product to the client
	public ArrayList<Product> getProductsList()
	{
		System.out.println("Got the request....");
		return service.getProductsList();
	}
	@GetMapping("/search")
	public String searchProduct(@RequestParam("pId") int productId)
	{
		return service.SearchById(productId);
	}
	//@pathVariable is used when the data is sent in this form
	@DeleteMapping(path="/deleteId/{pId}")
	//DeleteMapping is used to handle http DELETE request.If DELETE request then deleteProduct()method is called to delete the product
	
	public String  deleteProduct(@PathVariable("pId") int productId)
	{
		
		return service.deleteProduct(productId);
	}
	//Handling post Request
	/*@PostMapping is used receive POST request from the client ,
	 * if the Url end with /add and request type is POST ,then addProduct() method is called to add a product*/
	//@RequestBody is used when the client sends the data from a HtML form using either POST request or put request or delete request or UPDATE request
	//RequestBody contains the data sent by the client .
	/* All the data sent through a POST request must be stored in an object only
	 * So we define  POJO Class called Product 
	 * 	*Every API must declare the MIME format in which it accepts the data
	 * consumes attribute accept the data in specific format only .The client should send the data in format declared by the client
	 *  Dependency Injection is Followed .The object p for Product class is automatically created
	 *  and managed by spring boot framework.so p is  called java bean */
	
	@PostMapping(path="/add",consumes=MediaType.APPLICATION_JSON_VALUE)
	public String addProduct(@RequestBody Product p)
	
	{
		System.out.println("Got a POST request");
		return service.addProduct(p);
		
	}
	
	@PutMapping(path="/update",consumes=MediaType.APPLICATION_JSON_VALUE)
	
	public String updateProduct(@RequestBody Product p)
	{
		System.out.println("Got a Put request");
		return service.updateProduct(p.getProductId(), p.getProductName());
	}
	
	
}
