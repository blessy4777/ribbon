package BackendDevelopers.FirstSpringBoot.dao;

import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;

import BackendDevelopers.FirstSpringBoot.Model.Product;
@Repository
/*Product is the data that is inserted and Retrieved from the database
 * Integer is the datatype of the PrimaryKey
 */
public interface  ProductsList extends CrudRepository<Product,Integer> {
	
	

}
