package BackendDevelopers.FirstSpringBoot.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/* To create a Service select project>class>Add @Service it will become a Service  class
 * *Any  class marked with @Service Controls concurrent  or parallel
 * access to the DAo layer ,there by  preventing data loss or data ambiguity or data corruption
 * @Service automatically create a bean for ProductService
 */

import BackendDevelopers.FirstSpringBoot.Model.Product;
import BackendDevelopers.FirstSpringBoot.dao.ProductsList;

@Service
public class ProductService {
	
	//Manually injecting the Product list obj into the service
	@Autowired
	ProductsList plist;
	public ArrayList<Product> getProductsList()
	{
		System.out.println("Getting Products lists...");
		return (ArrayList<Product>)plist.findAll();
		/* when you call findAll() method in the repository it executes a SQL
		 * SQL select *from Products statement in the database. */
		
	}
	 public String addProduct(Product p)
		{
		 System.out.println("In service Adding product ...");
		 Product t=plist.save(p);// converts this to SQL insert statement.
		 return "<b>Added or Inserted the product</b>" +t;
		 
		 
		
		}
		public String deleteProduct(int ProductId)
		{
			 System.out.println("In service deleting product ...");
			 //for ex :if the ProductId is 3
			 // When deleteById() is called ,it convert this into 
			 // SQL Delete from Product where ProductId=3
			 plist.deleteById(ProductId);
			 return "<b>Deleted Product with ID </b>"+ProductId;
			 
			
		}
		public String SearchById(int ProductId)
		{
			 System.out.println("In service searching By id ...");
			 // If the ProductId is 4,this is converted into 
			 //SELECT *from Product where ProductId=4 
			 Optional<Product> opt=plist.findById(ProductId);
			 return "<b>Searched productID</b>"+opt.get().toString();
		}
		public String updateProduct(int ProductId,String newProductName)
		{
			 System.out.println("In service updating product...");
			 Product d=new Product(ProductId,newProductName);
			 // When save method is called ,if any Product with 
			 //given ProductId is existing ,it updates ProductName with the 
			 // newPeoductName otherwise it inserts a new record.
			 return "Updated Product with"+plist.save(d).toString();
		
		}

}
