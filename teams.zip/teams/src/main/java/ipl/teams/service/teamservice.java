package ipl.teams.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ipl.teams.dao.Team;
import ipl.teams.model.teamModel;

@Service
public class teamservice {
	@Autowired
	Team tlist;

	public List<teamModel> getTeamslist() {
		System.out.println("Getting Teams lists...");
		return (ArrayList<teamModel>) tlist.findAll();
	}

	public String addTeam(teamModel t) {
		System.out.println("In service Adding team ...");
		teamModel p = tlist.save(t);
		return "<b>Added or Inserted the Team </b>" + p;
	}

	public String deleteTeam(String teamId) {
		System.out.println("In service deleting team...");
		tlist.deleteById(teamId);
		return "<b>Deleted team with ID </b>" + teamId;

	}

	public String SearchById(String teamId) {
		System.out.println("In service searching By id ...");
		Optional<teamModel> opt = tlist.findById(teamId);
		return "<b>Searched team ID</b>" + opt.get().toString();
	}
	public String updateTeam(String TeamId,String newTeamName)
	{
		System.out.println("In service updating By id ...");
		teamModel d=new teamModel(TeamId,newTeamName);
		return "Updated Product"+tlist.save(d).toString();
	}

}
