package ipl.teams.model;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import jakarta.persistence.Column;

@Entity
@Table(name="team1")
public class teamModel {
	@Id
	private String teamId;
	@Column(name="teamName")
	private String teamName;
	public teamModel(String teamId, String teamName) {
		super();
		this.teamId = teamId;
		this.teamName = teamName;
 }
	public teamModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getTeamId() {
		return teamId;
	}
	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	@Override
	public String toString() {
		return "teamModel [teamId=" + teamId + ", teamName=" + teamName + "]";
	}

}
