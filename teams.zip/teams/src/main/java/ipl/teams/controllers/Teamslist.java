package ipl.teams.controllers;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ipl.teams.model.teamModel;
import ipl.teams.service.teamservice;
@RestController 
@RequestMapping("/teams")
public class Teamslist {
		public long visitorCount=0;
		
		@Autowired
		teamservice service;
		public Teamslist()
		{
			System.err.println("Team Controller created");
		}
		@RequestMapping(path="/",method=RequestMethod.GET)
		public String home() {
			visitorCount++;
			String response="<html><body><h1>";
			response +="WELCOME TO IPL TEAMS</h1><br>";
			response+="<b>You Are Visitor #</b>"+visitorCount;
			response+="</body></html>";
			return response;
		}
		@GetMapping(path="/teamlist",produces=MediaType.APPLICATION_JSON_VALUE)
		public ArrayList<teamModel> getteamsList()
		{
			return (ArrayList<teamModel>) service.getTeamslist();
		}
		@GetMapping("/search")
		public String searchteam(@RequestParam("tId") String  teamsId)
		{
			return service.SearchById(teamsId);
		}
		@DeleteMapping("/deleteId/{tId}")
		public String deleteTeam(@PathVariable("tId")String teamId)
		{
			return service.deleteTeam(teamId);
		}
		@PostMapping(path="/add", consumes=MediaType.APPLICATION_JSON_VALUE)
		public String addTeam(@RequestBody teamModel team)
		{
			return service.addTeam(team);
		}
		@PutMapping(path="/update",consumes=MediaType.APPLICATION_JSON_VALUE)
		public String updateTeam(@RequestBody teamModel p)
		
		{
			System.out.println("Got a Post request");
			return service.updateTeam(p.getTeamId(),p.getTeamName());
		}
		
		
	}

