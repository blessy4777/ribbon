package ipl.teams.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import ipl.teams.model.teamModel;

@Repository
public interface Team extends CrudRepository <teamModel ,String> {
  
	
}
